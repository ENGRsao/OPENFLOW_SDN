package org.testapp.app;

import com.google.common.collect.ForwardingObject;
//import com.sun.tools.jdi.Packet;
import org.onlab.packet.Ethernet;
import org.onlab.packet.MacAddress;
import org.onosproject.core.ApplicationId;
import org.onosproject.core.CoreService;
import org.onosproject.net.*;
import org.onosproject.net.flow.*;
import org.onosproject.net.flowobjective.DefaultForwardingObjective;
import org.onosproject.net.flowobjective.FlowObjectiveService;
import org.onosproject.net.flowobjective.ForwardingObjective;
import org.onosproject.net.packet.*;
import org.onosproject.net.topology.TopologyService;
import org.osgi.service.component.annotations.*;
import org.onosproject.net.host.HostService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Set;

/**
 * Skeletal ONOS application component.
 */
@Component(immediate = true)
public class AppComponent {


    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected CoreService coreService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected PacketService packetService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected HostService hostService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected TopologyService topologyService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected FlowObjectiveService flowObjectiveService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected FlowRuleService flowRuleService;

    private ApplicationId appId;

    private ReactivePacketProcessor processor = new ReactivePacketProcessor();

    private final Logger log = LoggerFactory.getLogger(getClass());

    @Activate
    protected void activate() {
        appId = coreService.registerApplication("org.testapp.app");

        packetService.addProcessor(processor, PacketProcessor.director(2));

        installIpv4FlowRule();

        log.info("Packet Logger application has been started with appId {}", appId);
    }

    @Deactivate
    protected void deactivate() {
        packetService.removeProcessor(processor);
        processor = null;

        removeIpv4FlowRule();

        log.info("Packet Logger application has been stopped with appId {}", appId);
    }

    private class ReactivePacketProcessor implements PacketProcessor {

        @Override
        public void process(PacketContext context) {

            InboundPacket pkt = context.inPacket();
            Ethernet ethPkt = pkt.parsed();

            if (ethPkt.getEtherType() == Ethernet.TYPE_LLDP) {
                //log.info("[---PACKLOGGED---]: from {} ETH_TYPE: LLDP", context.inPacket().receivedFrom());
            }

            if (ethPkt.getEtherType() == Ethernet.TYPE_ARP) {
                log.info("[---PACKLOGGED---]: from {} ETH_TYPE: ARP", context.inPacket().receivedFrom());
            }

            if (ethPkt.getEtherType() == Ethernet.TYPE_IPV4) {
                log.info("[---PACKLOGGED---]: from {} ETH_TYPE: IPv4", context.inPacket().receivedFrom());

                //Identify the destination host
                HostId id = HostId.hostId(ethPkt.getDestinationMAC());
                Host dst = hostService.getHost(id);

                //Identify the source host
                HostId idSrc = HostId.hostId(ethPkt.getSourceMAC());
                Host src = hostService.getHost(idSrc);


                if (dst == null) {
                    log.error("PCKLOG destination host is not known MAC {} ", ethPkt.getDestinationMAC());
                    return;
                }

                if (src == null) {
                    log.error("PCKLOG source host is not known MAC {} ", ethPkt.getSourceMAC());
                    return;
                }

                log.info("PCKLOG source host {} to destination {} ", ethPkt.getSourceMAC(), ethPkt.getDestinationMAC());

                DeviceId currentDeviceId = pkt.receivedFrom().deviceId();
                DeviceId hostLocation = src.location().deviceId();

                if (hostLocation.equals(currentDeviceId)) {
                    log.info("PCKLOG NEW PCK source host {} to destination {} from device {}", ethPkt.getSourceMAC(),
                            ethPkt.getDestinationMAC(), currentDeviceId);
                }

                Set<Path> paths =
                        topologyService.getPaths(topologyService.currentTopology(),
                        src.location().deviceId(),
                        dst.location().deviceId());
                log.warn("PCKLOG number {} paths are possible", paths.size());
                log.warn("PCKLOG paths {}",paths);
              /*  if (paths.isEmpty())
                {
                    log.error("- PCKLOG: path not found.");
                    return;
                }else{
                    log.info("-- PCKLOG: list of paths {}",paths);
                }*/
                Path path = paths.iterator().next();

                log.info("PCKLOG: path");
                for (Link link : path.links()){
                    log.info("....... Path link  {} / {}  --> {} /{}",
                            link.src().deviceId(),
                            link.src().port(),
                            link.dst().deviceId(),
                            link.dst().port()
                            );
                }

                if (currentDeviceId.equals(DeviceId.deviceId("of:1000000000000006"))){
                    installRule(context, currentDeviceId, src.location().port(),PortNumber.portNumber(4));
                    log.warn("--PCKLOG: ROUTING flow executed");
                }
                DeviceId destLocation = dst.location().deviceId();
                if (destLocation.equals(currentDeviceId)) {
                    log.info("PCKLOG NEW delivered to destination {} through device {} from source {}",
                            ethPkt.getDestinationMAC(),
                            currentDeviceId, ethPkt.getSourceMAC());
                }
            }
        }
    }

    private  void installRule(PacketContext context, DeviceId deviceId, PortNumber inPort, PortNumber outPort){
        InboundPacket pkt = context.inPacket();
        Ethernet ethPkt = pkt.parsed();

        MacAddress dstMAC = ethPkt.getDestinationMAC();
        MacAddress srcMAC = ethPkt.getSourceMAC();

        //Installing FlowRule
        TrafficSelector selector = DefaultTrafficSelector.builder()
                .matchEthSrc(srcMAC)
                .matchEthDst(dstMAC)
                .matchInPort(inPort)
                .build();

        TrafficTreatment treatment = DefaultTrafficTreatment.builder()
                    .setOutput(outPort)
                .build();
        //this is to genrate forwarding objectve, where table ID isnt specify and will be automatically selected by the device driver
        /*ForwardingObjective forwardingObjective = DefaultForwardingObjective.builder()
                .withSelector(selector)
                .withPriority(5)
                .withTreatment(treatment)
                .fromApp(appId)
                .add();

        flowObjectiveService.forward(deviceId,forwardingObjective);*/

        //This is to directly genrate the flow rule without using the device driver , so here we have to specify the table ID
        FlowRule rule = DefaultFlowRule.builder()
                .withSelector(selector)
                .withPriority(5)
                .withTreatment(treatment)
                .fromApp(appId)
                .forTable(0)
                .forDevice(deviceId)
                .makePermanent()
                .build();
        flowRuleService.applyFlowRules(rule);
    }

    private void installIpv4FlowRule() {
        TrafficSelector.Builder selector = DefaultTrafficSelector.builder();
        selector.matchEthType(Ethernet.TYPE_IPV4);
        packetService.requestPackets(selector.build(), PacketPriority.REACTIVE, appId);
    }

    /**
     * Cancel request for packet in via packet service.
     */
    private void removeIpv4FlowRule() {
        TrafficSelector.Builder selector = DefaultTrafficSelector.builder();
        selector.matchEthType(Ethernet.TYPE_IPV4);
        packetService.cancelPackets(selector.build(), PacketPriority.REACTIVE, appId);
    }

}